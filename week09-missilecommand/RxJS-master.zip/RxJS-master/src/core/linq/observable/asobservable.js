  /**
   *  Hides the identity of an observable sequence.
   * @returns {Observable} An observable sequence that hides the identity of the source sequence.    
   */
  observableProto.asObservable = function () {
    return new AnonymousObservable(this.subscribe.bind(this));
  };
